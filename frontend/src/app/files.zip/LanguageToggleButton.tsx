/**
 * LanguageToggleButton.tsx
 *
 * A reusable EN ↔ BM toggle button.
 * Drop this anywhere — Landing page nav, Sidebar, page headers, etc.
 * It reads and writes the global language state via useLanguage().
 *
 * Variants:
 *   "default"  — outlined pill button (for use in light/white navbars)
 *   "dark"     — white-bordered version (for use on dark backgrounds like Landing page)
 *   "ghost"    — minimal ghost style (for use inside sidebars)
 */

import { Globe } from "lucide-react";
import { useLanguage } from "./LanguageProvider";

type ButtonVariant = "default" | "dark" | "ghost";

interface LanguageToggleButtonProps {
  variant?: ButtonVariant;
  className?: string;
}

export function LanguageToggleButton({
  variant = "default",
  className = "",
}: LanguageToggleButtonProps) {
  const { language, toggleLanguage } = useLanguage();

  // The label always shows the TARGET language (what we're switching TO)
  const targetLabel = language === "en" ? "BM" : "EN";
  const title = language === "en" ? "Switch to Bahasa Malaysia" : "Tukar ke Bahasa Inggeris";

  const baseClasses =
    "inline-flex items-center gap-1.5 text-sm font-semibold transition-colors rounded-lg px-3 py-1.5 cursor-pointer";

  const variantClasses: Record<ButtonVariant, string> = {
    default:
      "text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700",
    dark:
      "text-white/80 border border-white/20 hover:text-white hover:border-white/40 bg-transparent",
    ghost:
      "text-gray-600 dark:text-slate-400 hover:bg-gray-100 dark:hover:bg-slate-800/50 hover:text-gray-900 dark:hover:text-white",
  };

  return (
    <button
      onClick={toggleLanguage}
      title={title}
      className={`${baseClasses} ${variantClasses[variant]} ${className}`}
    >
      <Globe className="w-4 h-4" />
      {targetLabel}
    </button>
  );
}
